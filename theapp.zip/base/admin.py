from django.contrib import admin
from .models import lawyer , OrderNow

admin.site.register(lawyer)
admin.site.register(OrderNow)

